package ch.heig.comem.spotplace.utilities;

public class ServerUrl {
	
	public String serverUrl = "10.192.80.198";
	public String serverPort = "8088";

}
