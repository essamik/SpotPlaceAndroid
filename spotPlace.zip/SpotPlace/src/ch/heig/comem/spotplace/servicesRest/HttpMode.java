package ch.heig.comem.spotplace.servicesRest;

public enum HttpMode {
	POST, GET, PUT, DELETE

}
